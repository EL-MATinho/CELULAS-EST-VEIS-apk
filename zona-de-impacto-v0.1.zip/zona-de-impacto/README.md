# ZONA DE IMPACTO — primeira versão jogável

Protótipo multiplayer PvPvE 2D com visual low-poly desenhado em Canvas. O projeto já inclui sala online, criação de personagem, seleção de arma, distribuição de pontos do carro, mapa urbano, três tipos de zumbi, tiros, direção, coleta de itens, placar e controles de celular.

## O que está implementado

- Servidor Node.js autoritativo com WebSocket (`ws`).
- Salas de 6 caracteres, mínimo de 2 e máximo de 8 jogadores.
- O anfitrião cria a sala; os demais entram com o código.
- Personagem com nome, cor de pele, cabelo e roupa.
- Pistola, submetralhadora, escopeta e rifle, cada uma com cadência, alcance, munição e dano diferentes.
- Carro individual, com 16 pontos para distribuir entre aceleração, velocidade máxima, controle e resistência.
- Mapa de cidade 2600 × 2000, com ruas, prédios, árvores, região central contaminada e pontos de saque.
- Zumbis comuns, corredores e brutamontes; eles perseguem jogadores e atacam.
- Tiros, recarga, dano, morte, pontuação, ondas de zumbis e fim de partida.
- Entrar/sair do carro, dirigir, colisões, atropelamentos, combustível e resistência do veículo.
- Itens de munição, kit médico, combustível e reparo.
- Controles de toque (joystick, tiro, interação) e teclado/mouse.
- Reconexão de sessão durante a vida da sala.

## Requisito importante: partidas em redes diferentes

Para jogadores em cidades, redes Wi-Fi ou operadoras diferentes, o servidor precisa estar acessível pela internet. Um servidor executado apenas no celular do anfitrião e limitado ao Wi-Fi local não atende esse requisito sem túnel público, VPN ou redirecionamento de portas.

Esta entrega usa um servidor Node.js que serve também a página do jogo. Publique-o em um serviço com URL HTTPS pública e suporte a WebSocket. O arquivo `render.yaml` já contém uma configuração inicial para Render.

### Publicar no Render

1. Crie um repositório no GitHub e envie todos os arquivos desta pasta, mantendo `server.js`, `package.json`, `render.yaml` e a pasta `public/` na raiz do repositório.
2. No Render, escolha **New → Blueprint** e conecte o repositório. Como alternativa, escolha **New → Web Service**, selecione o repositório e configure:
   - Build command: `npm install`
   - Start command: `npm start`
   - Health check path: `/health`
3. Selecione o plano disponível e aguarde a publicação. O serviço terá um endereço semelhante a `https://nome-do-jogo.onrender.com`.
4. Abra esse mesmo endereço em todos os celulares. O anfitrião toca em **Criar sala** e compartilha o código. Os outros escolhem seus personagens, digitam o código e entram.

Documentação oficial: https://render.com/docs/websocket e https://render.com/docs/free

**Limitação do plano gratuito:** serviços gratuitos podem dormir após um período sem tráfego e podem reiniciar. O estado das salas fica na memória do processo e é perdido quando o servidor reinicia. O plano gratuito serve para testes; para partidas contínuas, use uma instância que não suspenda e adicione armazenamento persistente caso queira histórico de resultados.

## Rodar localmente para teste

Requer Node.js 18 ou superior.

```bash
npm install
npm start
```

No computador anfitrião, abra `http://localhost:3000`.

Em outros aparelhos na mesma rede, abra o endereço de rede mostrado no terminal, por exemplo `http://192.168.0.15:3000`.

### Android com Termux

1. Instale Termux por uma fonte confiável.
2. Instale Node.js: `pkg update && pkg install nodejs git`
3. Coloque esta pasta no armazenamento do aparelho ou clone o repositório.
4. Entre na pasta do projeto e execute `npm install && npm start`.
5. Para partidas entre Wi-Fi diferentes, publique o mesmo projeto em um serviço público como descrito acima. O endereço local do Termux, sozinho, só funciona na rede local.

## Controles

### Celular
- Joystick esquerdo: andar; dentro do carro, acelerar/recuar e esterçar.
- Botão ATIRAR: disparo contínuo.
- Botão ENTRAR / USAR: entrar/sair do carro ou pegar item próximo.
- Botão RECARREGAR: recarregar a arma.
- Botão ACELERAR: aceleração contínua adicional quando estiver no carro.
- Toque no lado direito do campo de jogo para mirar e disparar.

### Computador
- WASD ou setas: movimentar.
- Mouse: mirar.
- Clique esquerdo: atirar.
- R: recarregar.
- E: entrar/sair do carro ou interagir.

## Regras atuais da primeira versão

- Vida inicial: 100.
- Partida: até 12 minutos.
- Zumbis começam no centro e novas unidades aparecem em ondas.
- Pontos: 2 por minuto sobrevivido, 2 a 5 por zumbi (dependendo do tipo), 8 por jogador eliminado e 25 de bônus para o último sobrevivente.
- Sem equipes nesta versão.

## Limitações conhecidas desta versão inicial

- O estado da partida vive na memória do servidor; uma reinicialização encerra as salas.
- Não há conta de usuário, persistência de estatísticas ou histórico entre partidas.
- O mapa e os gráficos são procedurais e simples, intencionalmente em 2D low-poly.
- A IA dos zumbis usa perseguição direta e desvio simples de obstáculos, não pathfinding avançado.
- A mira e os tiros são resolvidos no servidor com colisão simplificada; não há projéteis físicos ou animações avançadas de impacto.
- Não há voz, chat, matchmaking público, inventário persistente ou anti-cheat avançado.
- O limite de oito jogadores é inicial e deve ser testado em rede real antes de ampliar.

## Estrutura

```text
zona-de-impacto/
├── package.json
├── server.js
├── render.yaml
├── README.md
└── public/
    ├── index.html
    ├── style.css
    ├── client.js
    └── world-data.js
```
