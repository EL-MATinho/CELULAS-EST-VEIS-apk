'use strict';

(() => {
  const $ = id => document.getElementById(id);
  const screens = { setup: $('setupScreen'), lobby: $('lobbyScreen'), game: $('gameScreen') };
  const canvas = $('gameCanvas');
  const ctx = canvas.getContext('2d', { alpha: false });
  const mini = $('minimap');
  const mctx = mini.getContext('2d');
  const WORLD = window.ZI_WORLD;
  const PRESETS = {
    balanced: { acceleration: 4, topSpeed: 4, handling: 4, durability: 4 },
    turbo: { acceleration: 6, topSpeed: 2, handling: 5, durability: 3 },
    speed: { acceleration: 3, topSpeed: 6, handling: 4, durability: 3 },
    reinforced: { acceleration: 3, topSpeed: 3, handling: 4, durability: 6 }
  };
  const WEAPON_LABELS = { pistol: 'PISTOLA', smg: 'SUBMETRALHADORA', shotgun: 'ESCOPETA', rifle: 'RIFLE' };
  const state = {
    socket: null, connected: false, manualClose: false, reconnectTimer: null, reconnectAttempt: 0,
    roomCode: '', playerId: '', token: '', isHost: false, gameState: null,
    profile: { name: 'Sobrevivente', color: '#dca879', hair: '#2c2523', outfit: '#526b62', weapon: 'pistol', car: { ...PRESETS.balanced } },
    input: { mx: 0, my: 0, ax: 1, ay: 0, shoot: false, reload: false, interact: false, accelerate: 0, steer: 0, brake: false },
    pointer: { down: false, id: null, x: 0, y: 0 }, joystick: { active: false, id: null, x: 0, y: 0 },
    lastState: 0, lastSend: 0, toastTimer: null, frame: 0, lastFrame: 0, currentAim: 0, hasAim: false
  };

  function toast(message) {
    const el = $('toast'); el.textContent = message; el.classList.add('show');
    clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => el.classList.remove('show'), 2600);
  }
  function gameNotice(message) {
    const el = $('noticeToast'); el.textContent = message; el.classList.add('show');
    setTimeout(() => el.classList.remove('show'), 2200);
  }
  function showScreen(name) {
    Object.entries(screens).forEach(([key, el]) => el.classList.toggle('hidden', key !== name));
    if (name === 'game') {
      resizeCanvas(); startRenderLoop(); updateHud();
      document.body.style.overflow = 'hidden';
    } else {
      stopRenderLoop(); document.body.style.overflow = '';
    }
  }
  function updateConnectionBadge(status, label) {
    const el = $('connectionBadge'); el.className = `connection-badge ${status}`; el.textContent = label;
  }
  function makeWsUrl() {
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    return `${proto}//${location.host}/ws`;
  }
  function connect() {
    if (state.socket && (state.socket.readyState === WebSocket.OPEN || state.socket.readyState === WebSocket.CONNECTING)) return;
    state.manualClose = false;
    let ws;
    try { ws = new WebSocket(makeWsUrl()); } catch { updateConnectionBadge('offline', 'SEM CONEXÃO'); return; }
    state.socket = ws;
    ws.addEventListener('open', () => {
      state.connected = true; state.reconnectAttempt = 0; updateConnectionBadge('online', 'SERVIDOR CONECTADO');
      const saved = readSession();
      if (saved && saved.roomCode && saved.token) {
        ws.send(JSON.stringify({ type: 'reconnect', roomCode: saved.roomCode, token: saved.token }));
      }
    });
    ws.addEventListener('message', event => {
      let msg; try { msg = JSON.parse(event.data); } catch { return; }
      handleMessage(msg);
    });
    ws.addEventListener('close', () => {
      state.connected = false; updateConnectionBadge('offline', 'DESCONECTADO');
      if (!state.manualClose) {
        const delay = Math.min(12000, 900 * Math.pow(1.7, state.reconnectAttempt++));
        clearTimeout(state.reconnectTimer); state.reconnectTimer = setTimeout(connect, delay);
        if (!screens.game.classList.contains('hidden')) gameNotice('Conexão perdida. Tentando reconectar...');
      }
    });
    ws.addEventListener('error', () => { updateConnectionBadge('offline', 'ERRO DE REDE'); });
  }
  function readSession() {
    try { return JSON.parse(localStorage.getItem('ziSession') || 'null'); } catch { return null; }
  }
  function saveSession() {
    localStorage.setItem('ziSession', JSON.stringify({ roomCode: state.roomCode, token: state.token }));
  }
  function clearSession() { localStorage.removeItem('ziSession'); }
  function send(type, payload = {}) {
    if (!state.socket || state.socket.readyState !== WebSocket.OPEN) { toast('Sem conexão com o servidor.'); return false; }
    state.socket.send(JSON.stringify({ type, ...payload })); return true;
  }
  function getProfile() {
    state.profile.name = $('playerName').value.trim().slice(0, 18) || 'Sobrevivente';
    state.profile.color = selectedSkin;
    state.profile.hair = $('hairColor').value;
    state.profile.outfit = $('outfitColor').value;
    state.profile.weapon = document.querySelector('.weapon-card.selected')?.dataset.weapon || 'pistol';
    state.profile.token = state.token || localStorage.getItem('ziToken') || createToken();
    state.token = state.profile.token; localStorage.setItem('ziToken', state.token);
    state.profile.car = getCarValues();
    return { ...state.profile, car: { ...state.profile.car } };
  }
  function createToken() {
    const bytes = new Uint8Array(20); crypto.getRandomValues(bytes);
    return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
  }
  function handleMessage(msg) {
    if (msg.type === 'joined') {
      state.roomCode = msg.roomCode; state.playerId = msg.playerId; state.token = msg.token; state.isHost = !!msg.isHost;
      saveSession();
      if (msg.state) updateGameState(msg.state);
      if (msg.state?.phase === 'running') { showScreen('game'); $('deadOverlay').classList.add('hidden'); }
      else showLobby();
    } else if (msg.type === 'state') {
      updateGameState(msg.state);
      if (msg.state.phase === 'running' && screens.game.classList.contains('hidden')) {
        $('deadOverlay').classList.add('hidden'); $('endOverlay').classList.add('hidden'); showScreen('game');
      }
    } else if (msg.type === 'notice') {
      gameNotice(msg.text || '');
      if (screens.lobby.classList.contains('hidden')) return;
      $('lobbyMessage').textContent = msg.text || '';
    } else if (msg.type === 'error') {
      toast(msg.message || 'Ocorreu um erro.');
      if ((msg.message || '').includes('Sessão não encontrada') || (msg.message || '').includes('sala não está mais')) clearSession();
    } else if (msg.type === 'gameOver') {
      showGameOver(msg);
    } else if (msg.type === 'left') {
      state.roomCode = ''; state.playerId = ''; state.isHost = false; clearSession(); showScreen('setup');
    }
  }
  function updateGameState(gameState) {
    if (!gameState) return;
    state.gameState = gameState; state.lastState = performance.now();
    if (!screens.lobby.classList.contains('hidden')) renderLobby();
    if (!screens.game.classList.contains('hidden')) updateHud();
  }
  function showLobby() {
    $('roomCodeDisplay').textContent = state.roomCode || '------';
    $('lobbyMessage').textContent = state.isHost ? 'Você é o anfitrião. Aguarde pelo menos mais um jogador.' : 'Conectado. Aguardando o anfitrião iniciar...';
    showScreen('lobby'); renderLobby();
  }
  function renderLobby() {
    const gs = state.gameState; if (!gs) return;
    $('roomCodeDisplay').textContent = gs.code || state.roomCode;
    const players = gs.players || [];
    $('playerCount').textContent = `${players.filter(p => p.connected).length} / 8`;
    $('lobbyPlayers').innerHTML = players.map(p => `<div class="lobby-player"><span class="player-dot" style="--skin:${p.color};--outfit:${p.outfit}"></span><div><b>${escapeHtml(p.name)}</b><small>${p.connected ? 'CONECTADO' : 'RECONEXÃO PENDENTE'} · ${escapeHtml(WEAPON_LABELS[p.weapon] || p.weapon)}</small></div>${p.host ? '<span class="host-tag">HOST</span>' : ''}</div>`).join('');
    const count = players.filter(p => p.connected).length;
    $('startGameBtn').disabled = !state.isHost || count < 2;
    $('startGameBtn').style.opacity = state.isHost ? '1' : '.4';
    $('lobbyMessage').textContent = count < 2 ? 'Aguardando pelo menos mais um jogador...' : state.isHost ? 'Tudo pronto. Inicie quando desejar.' : 'Jogadores conectados. Aguardando o anfitrião.';
  }
  function escapeHtml(value) { return String(value).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])); }

  // Character customization
  let selectedSkin = '#dca879';
  $('skinSwatches').addEventListener('click', e => {
    const btn = e.target.closest('.swatch'); if (!btn) return;
    document.querySelectorAll('.swatch').forEach(x => x.classList.remove('selected'));
    btn.classList.add('selected'); selectedSkin = btn.dataset.value; updateAvatarPreview();
  });
  $('hairColor').addEventListener('change', updateAvatarPreview);
  $('outfitColor').addEventListener('change', updateAvatarPreview);
  function updateAvatarPreview() {
    $('avatarPreview').style.setProperty('--skin', selectedSkin);
    $('avatarPreview').style.setProperty('--hair', $('hairColor').value);
    $('avatarPreview').style.setProperty('--outfit', $('outfitColor').value);
  }
  document.querySelectorAll('.weapon-card').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.weapon-card').forEach(x => x.classList.remove('selected')); btn.classList.add('selected');
  }));

  function getCarValues() {
    return { acceleration: +$('acceleration').value, topSpeed: +$('topSpeed').value, handling: +$('handling').value, durability: +$('durability').value };
  }
  function updateCarLabels() {
    const v = getCarValues();
    for (const [k, val] of Object.entries(v)) $(`${k}Value`).textContent = val;
    $('budgetValue').textContent = Object.values(v).reduce((a,b)=>a+b,0);
  }
  function setCarValues(values) {
    for (const k of Object.keys(values)) $(k).value = values[k];
    updateCarLabels();
  }
  function adjustCarBudget(changedKey) {
    let v = getCarValues(); let sum = Object.values(v).reduce((a,b)=>a+b,0);
    let diff = sum - 16;
    const order = Object.keys(v).filter(k => k !== changedKey);
    while (diff > 0) {
      const k = order.find(key => v[key] > 1); if (!k) break; v[k]--; diff--;
    }
    while (diff < 0) {
      const k = order.find(key => v[key] < 7); if (!k) break; v[k]++; diff++;
    }
    setCarValues(v);
    document.querySelectorAll('.engine-chip').forEach(x => x.classList.remove('selected'));
  }
  ['acceleration','topSpeed','handling','durability'].forEach(k => $(k).addEventListener('input', () => adjustCarBudget(k)));
  document.querySelectorAll('.engine-chip').forEach(btn => btn.addEventListener('click', () => {
    document.querySelectorAll('.engine-chip').forEach(x => x.classList.remove('selected')); btn.classList.add('selected');
    setCarValues(PRESETS[btn.dataset.engine]);
  }));

  $('createRoomBtn').addEventListener('click', () => {
    if (!state.connected) return toast('Aguarde a conexão com o servidor.');
    state.token = createToken(); localStorage.setItem('ziToken', state.token);
    send('createRoom', { profile: getProfile() });
  });
  $('joinRoomBtn').addEventListener('click', () => {
    if (!state.connected) return toast('Aguarde a conexão com o servidor.');
    const roomCode = $('roomCodeInput').value.trim().toUpperCase();
    if (roomCode.length !== 6) return toast('Informe um código de sala com 6 caracteres.');
    state.token = createToken(); localStorage.setItem('ziToken', state.token);
    send('joinRoom', { roomCode, profile: getProfile() });
  });
  $('roomCodeInput').addEventListener('input', e => e.target.value = e.target.value.toUpperCase().replace(/[^A-F0-9]/g, '').slice(0,6));
  $('copyCodeBtn').addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(state.roomCode); toast('Código copiado.'); }
    catch { toast(`Código da sala: ${state.roomCode}`); }
  });
  $('startGameBtn').addEventListener('click', () => send('startGame'));
  $('backSetupBtn').addEventListener('click', () => {
    send('leaveRoom'); state.roomCode = ''; state.isHost = false; clearSession(); showScreen('setup');
  });
  $('leaveGameBtn').addEventListener('click', () => {
    if (confirm('Sair desta partida?')) { send('leaveRoom'); state.roomCode = ''; state.playerId = ''; state.gameState = null; clearSession(); showScreen('setup'); }
  });
  $('returnMenuBtn').addEventListener('click', () => {
    send('leaveRoom'); state.roomCode = ''; state.playerId = ''; state.gameState = null; clearSession(); showScreen('setup');
  });
  $('reloadBtn').addEventListener('click', () => { state.input.reload = true; setTimeout(() => state.input.reload = false, 100); });
  $('interactBtn').addEventListener('pointerdown', e => { e.preventDefault(); state.input.interact = true; });
  ['pointerup','pointercancel','pointerleave'].forEach(ev => $('interactBtn').addEventListener(ev, () => state.input.interact = false));
  $('fireBtn').addEventListener('pointerdown', e => { e.preventDefault(); state.input.shoot = true; });
  ['pointerup','pointercancel','pointerleave'].forEach(ev => $('fireBtn').addEventListener(ev, () => state.input.shoot = false));
  $('driveBtn').addEventListener('pointerdown', e => { e.preventDefault(); state.input.accelerate = 1; });
  ['pointerup','pointercancel','pointerleave'].forEach(ev => $('driveBtn').addEventListener(ev, () => state.input.accelerate = 0));
  $('spectateBtn').addEventListener('click', () => $('deadOverlay').classList.add('hidden'));

  // Touch joystick
  const joystick = $('moveJoystick'); const joyBase = joystick.querySelector('.joy-base'); const joyKnob = $('moveKnob');
  function joystickStart(e) { e.preventDefault(); state.joystick.active = true; state.joystick.id = e.pointerId; joyBase.setPointerCapture?.(e.pointerId); joystickMove(e); }
  function joystickMove(e) {
    if (!state.joystick.active || (state.joystick.id !== null && e.pointerId !== state.joystick.id)) return;
    const r = joyBase.getBoundingClientRect(); const cx = r.left + r.width/2, cy = r.top + r.height/2;
    let dx = (e.clientX-cx)/(r.width*.34), dy = (e.clientY-cy)/(r.height*.34); const mag = Math.hypot(dx,dy);
    if (mag > 1) { dx /= mag; dy /= mag; }
    state.input.mx = dx; state.input.my = dy;
    joyKnob.style.transform = `translate(${dx*27}px,${dy*27}px)`;
  }
  function joystickEnd(e) {
    if (state.joystick.id !== null && e.pointerId !== state.joystick.id) return;
    state.joystick.active = false; state.joystick.id = null; state.input.mx = 0; state.input.my = 0; joyKnob.style.transform = 'translate(0,0)';
  }
  joyBase.addEventListener('pointerdown', joystickStart);
  joyBase.addEventListener('pointermove', joystickMove);
  joyBase.addEventListener('pointerup', joystickEnd);
  joyBase.addEventListener('pointercancel', joystickEnd);

  // Aim / shoot with right-side touch or mouse.
  function setAim(clientX, clientY) {
    const r = canvas.getBoundingClientRect();
    const dx = clientX - (r.left + r.width/2), dy = clientY - (r.top + r.height/2);
    const mag = Math.hypot(dx,dy) || 1;
    state.input.ax = dx / mag; state.input.ay = dy / mag; state.hasAim = true;
  }
  canvas.addEventListener('pointerdown', e => {
    if (e.pointerType === 'mouse') { setAim(e.clientX,e.clientY); state.input.shoot = true; state.pointer.down = true; }
    else if (e.clientX > window.innerWidth * .46) { setAim(e.clientX,e.clientY); state.input.shoot = true; state.pointer.down = true; state.pointer.id = e.pointerId; }
  });
  canvas.addEventListener('pointermove', e => {
    if (state.pointer.down && (state.pointer.id === null || e.pointerId === state.pointer.id)) setAim(e.clientX,e.clientY);
  });
  ['pointerup','pointercancel','pointerleave'].forEach(ev => canvas.addEventListener(ev, () => { state.input.shoot = false; state.pointer.down = false; state.pointer.id = null; }));
  window.addEventListener('keydown', e => {
    if (e.repeat || !screens.game || screens.game.classList.contains('hidden')) return;
    if (e.key.toLowerCase() === 'w' || e.key === 'ArrowUp') state.input.my = -1;
    if (e.key.toLowerCase() === 's' || e.key === 'ArrowDown') state.input.my = 1;
    if (e.key.toLowerCase() === 'a' || e.key === 'ArrowLeft') state.input.mx = -1;
    if (e.key.toLowerCase() === 'd' || e.key === 'ArrowRight') state.input.mx = 1;
    if (e.key.toLowerCase() === 'r') state.input.reload = true;
    if (e.key.toLowerCase() === 'e') state.input.interact = true;
    if (e.code === 'Space') state.input.shoot = true;
  });
  window.addEventListener('keyup', e => {
    if (e.key.toLowerCase() === 'w' || e.key === 'ArrowUp') if(state.input.my < 0) state.input.my = 0;
    if (e.key.toLowerCase() === 's' || e.key === 'ArrowDown') if(state.input.my > 0) state.input.my = 0;
    if (e.key.toLowerCase() === 'a' || e.key === 'ArrowLeft') if(state.input.mx < 0) state.input.mx = 0;
    if (e.key.toLowerCase() === 'd' || e.key === 'ArrowRight') if(state.input.mx > 0) state.input.mx = 0;
    if (e.key.toLowerCase() === 'r') state.input.reload = false;
    if (e.key.toLowerCase() === 'e') state.input.interact = false;
    if (e.code === 'Space') state.input.shoot = false;
  });

  // Send input at 20 Hz; host simulation remains authoritative.
  setInterval(() => {
    if (!state.connected || state.gameState?.phase !== 'running') return;
    const me = getLocalPlayer();
    const inCar = !!me?.inCar;
    const payload = { ...state.input };
    if (inCar) {
      payload.accelerate = state.input.accelerate || -state.input.my;
      payload.steer = state.input.mx;
      payload.mx = 0; payload.my = 0;
    }
    send('input', { input: payload });
  }, 50);

  setInterval(() => {
    if (state.connected && state.roomCode && state.gameState?.phase === 'lobby') send('keepalive');
  }, 15000);

  function getLocalPlayer() { return state.gameState?.players?.find(p => p.id === state.playerId) || null; }
  function updateHud() {
    const me = getLocalPlayer(); if (!me) return;
    $('healthBar').style.width = `${Math.max(0, me.hp)}%`; $('healthText').textContent = Math.max(0, Math.ceil(me.hp));
    $('scoreText').textContent = me.score; $('killsText').textContent = me.zombieKills + me.playerKills;
    $('weaponLabel').textContent = WEAPON_LABELS[me.weapon] || me.weapon.toUpperCase();
    $('ammoText').textContent = me.ammo; $('reserveText').textContent = me.reserve;
    $('carStatus').textContent = me.inCar ? 'DIRIGINDO' : me.carHp <= 0 ? 'VEÍCULO DESTRUÍDO' : 'FORA DO CARRO';
    $('carBar').style.width = `${Math.max(0, me.carHp / (me.carMaxHp || 1) * 100)}%`;
    $('fuelText').textContent = `COMBUSTÍVEL ${Math.round(me.fuel)}%`;
    $('driveBtn').classList.toggle('hidden', !me.inCar);
    const remaining = Math.max(0, state.gameState.remainingMs || 0);
    $('timerLabel').textContent = `${String(Math.floor(remaining/60000)).padStart(2,'0')}:${String(Math.floor(remaining/1000)%60).padStart(2,'0')}`;
    $('phaseLabel').textContent = state.gameState.zombies?.length > 20 ? 'HORDA CRÍTICA' : 'INVASÃO ATIVA';
    if (!me.alive) $('deadOverlay').classList.remove('hidden');
    else $('deadOverlay').classList.add('hidden');
  }
  setInterval(() => { if (!screens.game.classList.contains('hidden')) updateHud(); }, 250);

  function showGameOver(msg) {
    $('endTitle').textContent = msg.winner ? `${msg.winner.toUpperCase()} VENCEU` : 'ZONA ENCERRADA';
    $('endSubtitle').textContent = msg.reason === 'last-survivor' ? 'Último sobrevivente da zona.' : 'Tempo máximo alcançado. Resultado por pontuação.';
    $('rankingList').innerHTML = (msg.ranking || []).map(row => `<div class="ranking-item"><b>#${row.position}</b><div><b>${escapeHtml(row.name)}</b><small>${row.survivalSeconds}s sobrevivido · ${row.zombieKills} zumbis · ${row.playerKills} jogadores</small></div><span>${row.score} PTS</span></div>`).join('');
    $('endOverlay').classList.remove('hidden');
  }

  // Low-poly 2D renderer. All visual sprites are drawn procedurally, so no external sprite downloads are needed.
  let dpr = 1, cw = 0, ch = 0, renderRunning = false;
  function resizeCanvas() {
    const rect = canvas.getBoundingClientRect(); dpr = Math.min(1.6, window.devicePixelRatio || 1);
    cw = Math.max(1, rect.width); ch = Math.max(1, rect.height);
    canvas.width = Math.round(cw*dpr); canvas.height = Math.round(ch*dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  window.addEventListener('resize', () => { if (!screens.game.classList.contains('hidden')) resizeCanvas(); });
  function startRenderLoop() { if (renderRunning) return; renderRunning = true; state.lastFrame = performance.now(); requestAnimationFrame(renderLoop); }
  function stopRenderLoop() { renderRunning = false; }
  function renderLoop(now) {
    if (!renderRunning) return;
    renderGame(now); state.frame = requestAnimationFrame(renderLoop);
  }
  function polygon(c, points, fill, stroke = null, width = 1) {
    c.beginPath(); c.moveTo(points[0][0],points[0][1]);
    for (let i=1;i<points.length;i++) c.lineTo(points[i][0],points[i][1]);
    c.closePath(); if (fill) { c.fillStyle=fill; c.fill(); }
    if (stroke) { c.strokeStyle=stroke; c.lineWidth=width; c.stroke(); }
  }
  function rect(c,x,y,w,h,fill,stroke=null) { c.fillStyle=fill; c.fillRect(x,y,w,h); if(stroke){c.strokeStyle=stroke;c.strokeRect(x,y,w,h);} }
  function drawBuilding(b) {
    const type=b[4], palettes=[['#536257','#758477','#344138'],['#5d6258','#82816e','#383e35'],['#4b5d5c','#758b82','#35423f']][type];
    ctx.fillStyle='#0a100d55';ctx.fillRect(b[0]+12,b[1]+13,b[2],b[3]);
    rect(ctx,b[0],b[1],b[2],b[3],palettes[0],'#26352b');
    polygon(ctx,[[b[0],b[1]],[b[0]+17,b[1]-13],[b[0]+b[2]+16,b[1]-13],[b[0]+b[2],b[1]]],palettes[1],'#9ba18a33');
    polygon(ctx,[[b[0]+b[2],b[1]],[b[0]+b[2]+16,b[1]-13],[b[0]+b[2]+16,b[1]+b[3]-12],[b[0]+b[2],b[1]+b[3]]],palettes[2]);
    rect(ctx,b[0]+12,b[1]+17,b[17] || 17,7,'#a9ae8d55');
    for(let x=b[0]+20;x<b[0]+b[2]-12;x+=34){rect(ctx,x,b[1]+37,12,16,'#263d37');rect(ctx,x+2,b[1]+39,8,12,'#879887');}
    for(let x=b[0]+20;x<b[0]+b[2]-12;x+=34){rect(ctx,x,b[1]+b[3]-28,12,15,'#243a34');}
    rect(ctx,b[0]+b[2]*.43,b[1]+b[3]-33,25,33,'#2a3830');
    polygon(ctx,[[b[0]+b[2]*.43,b[1]+b[3]-33],[b[0]+b[2]*.43+25,b[1]+b[3]-33],[b[0]+b[2]*.43+21,b[1]+b[3]-38],[b[0]+b[2]*.43+4,b[1]+b[3]-38]],'#b08b59');
    // HVAC and debris add flat polygon facets.
    rect(ctx,b[0]+b[2]-42,b[1]+12,24,14,'#43534a');rect(ctx,b[0]+b[2]-39,b[1]+15,18,2,'#9ba28c66');
  }
  function drawTree(x,y) {
    ctx.fillStyle='#0007';ctx.beginPath();ctx.ellipse(x+3,y+8,17,8,0,0,Math.PI*2);ctx.fill();
    polygon(ctx,[[x-2,y+10],[x+2,y+10],[x+3,y-7],[x-1,y-7]],'#614f3a');
    polygon(ctx,[[x,y-29],[x-15,y-14],[x-12,y+1],[x+3,y+8],[x+17,y-1],[x+14,y-17]],'#48634b','#253d2b');
    polygon(ctx,[[x,y-29],[x-5,y-12],[x+2,y-6],[x+15,y-17]],'#6f8a61');
    polygon(ctx,[[x-15,y-14],[x-12,y+1],[x+3,y+8],[x+1,y-9]],'#3d5a44');
  }
  function drawLoot(item) {
    const colors={ammo:'#d6a24f',medkit:'#bb6b5e',fuel:'#6f9ca0',repair:'#9d9e78'};
    const labels={ammo:'A',medkit:'+',fuel:'F',repair:'R'};
    ctx.fillStyle='#0007';ctx.beginPath();ctx.ellipse(item.x,item.y+9,12,5,0,0,Math.PI*2);ctx.fill();
    rect(ctx,item.x-8,item.y-9,16,17,colors[item.kind],'#d6dec8');
    polygon(ctx,[[item.x-8,item.y-9],[item.x-3,item.y-13],[item.x+12,item.y-13],[item.x+8,item.y-9]],'#d6c69e');
    ctx.fillStyle='#182018';ctx.font='bold 10px sans-serif';ctx.textAlign='center';ctx.fillText(labels[item.kind],item.x,item.y+3);
  }
  function drawCar(x,y,angle,color='#b67843',hp=100) {
    ctx.save();ctx.translate(x,y);ctx.rotate(angle);
    ctx.fillStyle='#0008';ctx.beginPath();ctx.ellipse(0,5,29,16,0,0,Math.PI*2);ctx.fill();
    rect(ctx,-22,-15,11,6,'#101311');rect(ctx,12,-15,11,6,'#101311');rect(ctx,-22,9,11,6,'#101311');rect(ctx,12,9,11,6,'#101311');
    polygon(ctx,[[-27,-10],[-19,-15],[18,-15],[27,-9],[29,0],[27,10],[18,15],[-20,15],[-28,9],[-30,0]],color,'#1a211c',2);
    polygon(ctx,[[-14,-11],[10,-11],[18,-7],[18,7],[10,11],[-14,11],[-19,6],[-19,-6]],'#2b4140','#17241e',1);
    polygon(ctx,[[-15,-10],[0,-9],[0,9],[-15,9],[-20,5],[-20,-5]],'#83948a');
    polygon(ctx,[[2,-9],[11,-9],[16,-5],[16,5],[11,9],[2,9]],'#627b71');
    polygon(ctx,[[18,-13],[26,-8],[28,-2],[20,-3]],'#dfc18a');
    polygon(ctx,[[18,13],[26,8],[28,2],[20,3]],'#b54f3b');
    polygon(ctx,[[-25,-7],[-28,-4],[-28,4],[-25,7]],'#c6b18b');
    rect(ctx,-4,-12,2,24,'#18241f');
    ctx.restore();
    if (hp < 65) { ctx.strokeStyle='#b76b4c';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,23,-2.1,-.9);ctx.stroke(); }
  }
  function drawPlayer(p) {
    if (!p.alive) return;
    if (p.inCar) return;
    ctx.save();ctx.translate(p.x,p.y);ctx.rotate(p.angle||0);
    ctx.fillStyle='#0008';ctx.beginPath();ctx.ellipse(1,7,15,8,0,0,Math.PI*2);ctx.fill();
    polygon(ctx,[[-8,-5],[-5,-12],[5,-12],[9,-4],[8,10],[-7,10]],p.outfit,'#1e2b22',1);
    polygon(ctx,[[-6,-3],[0,-9],[6,-4],[6,7],[-5,7]],'#d4d0b6');
    ctx.fillStyle=p.color;ctx.beginPath();ctx.arc(0,-13,7,0,Math.PI*2);ctx.fill();
    polygon(ctx,[[-7,-16],[-5,-21],[4,-21],[8,-16],[3,-14],[-5,-14]],p.hair);
    rect(ctx,5,-4,12,4,'#343b32');
    polygon(ctx,[[9,-5],[22,-3],[22,0],[8,-1]],'#4c4b3e');
    ctx.restore();
    if (p.id===state.playerId) { ctx.strokeStyle='#f1d18e';ctx.lineWidth=1;ctx.beginPath();ctx.arc(p.x,p.y,20,0,Math.PI*2);ctx.stroke(); }
    ctx.fillStyle='#e1e4d8';ctx.font='bold 9px Manrope';ctx.textAlign='center';ctx.fillText(p.name,p.x,p.y-26);
  }
  function drawZombie(z, now) {
    const size=z.type==='brute'?1.35:z.type==='runner'?.82:1;
    const body=z.type==='brute'?'#687d5d':z.type==='runner'?'#8a9673':'#72866c';
    ctx.save();ctx.translate(z.x,z.y);ctx.rotate(z.angle||0);ctx.scale(size,size);
    ctx.fillStyle='#0008';ctx.beginPath();ctx.ellipse(0,7,15,7,0,0,Math.PI*2);ctx.fill();
    const sway=Math.sin(now/140+z.x*.02)*2;
    polygon(ctx,[[-6,-4],[-7,-12],[0,-15],[7,-9],[9,5],[3,11],[-8,8]],body,'#253b2b',1);
    polygon(ctx,[[-6,-6],[-3,-12],[2,-13],[6,-8],[1,-3]],'#9bab7c');
    ctx.fillStyle='#9c4e42';ctx.beginPath();ctx.arc(0,-14,6,0,Math.PI*2);ctx.fill();
    polygon(ctx,[[-6,-18],[-3,-22],[3,-21],[7,-16],[3,-12],[-4,-12]],'#859a73');
    rect(ctx,-4,-18,2,2,'#d95d4d');rect(ctx,3,-18,2,2,'#d95d4d');
    polygon(ctx,[[-5,6],[-9,14+sway],[-5,15+sway],[0,7]],'#53614b');
    polygon(ctx,[[4,7],[8,14-sway],[11,13-sway],[7,4]],'#53614b');
    if (z.type==='brute') { polygon(ctx,[[-9,-7],[-13,-11],[-14,-4],[-8,2]],'#536b52');polygon(ctx,[[8,-7],[14,-11],[15,-3],[8,2]],'#536b52'); }
    ctx.restore();
    if (z.hp < z.maxHp) { ctx.fillStyle='#182219';ctx.fillRect(z.x-12,z.y-26,24,3);ctx.fillStyle='#bf6550';ctx.fillRect(z.x-12,z.y-26,24*Math.max(0,z.hp/z.maxHp),3); }
  }
  function drawWorldBackground(camX,camY) {
    ctx.fillStyle='#364739';ctx.fillRect(0,0,WORLD.width,WORLD.height);
    // Ground facets and sparse dry-grass marks.
    for(let x=Math.floor(camX/130)*130-100;x<camX+cw+130;x+=130) for(let y=Math.floor(camY/130)*130-100;y<camY+ch+130;y+=130){
      polygon(ctx,[[x,y],[x+60,y-18],[x+130,y+18],[x+75,y+65]],'#43574422');
      if((Math.floor(x/130)+Math.floor(y/130))%3===0){ctx.strokeStyle='#81906b55';ctx.beginPath();ctx.moveTo(x+42,y+88);ctx.lineTo(x+49,y+76);ctx.stroke();}
    }
    for(const road of WORLD.roads){rect(ctx,road.x,road.y,road.w,road.h,'#414844');rect(ctx,road.x,road.y,road.w,3,'#657066');rect(ctx,road.x,road.y+road.h-3,road.w,3,'#252f29');}
    ctx.strokeStyle='#c4b78a66';ctx.lineWidth=3;ctx.setLineDash([28,24]);
    for(const road of WORLD.roads){if(road.w>road.h){ctx.beginPath();ctx.moveTo(road.x,road.y+road.h/2);ctx.lineTo(road.x+road.w,road.y+road.h/2);ctx.stroke();}else{ctx.beginPath();ctx.moveTo(road.x+road.w/2,road.y);ctx.lineTo(road.x+road.w/2,road.y+road.h);ctx.stroke();}}
    ctx.setLineDash([]);
    // Center contamination zone.
    const g=ctx.createRadialGradient(WORLD.center.x,WORLD.center.y,35,WORLD.center.x,WORLD.center.y,420);g.addColorStop(0,'#9a4b3c44');g.addColorStop(1,'#9a4b3c00');ctx.fillStyle=g;ctx.beginPath();ctx.arc(WORLD.center.x,WORLD.center.y,420,0,Math.PI*2);ctx.fill();
    for(const t of WORLD.trees) if(t[0]>camX-90&&t[0]<camX+cw+90&&t[1]>camY-90&&t[1]<camY+ch+90) drawTree(t[0],t[1]);
    for(const b of WORLD.buildings) if(b[0]+b[2]>camX-100&&b[0]<camX+cw+100&&b[1]+b[3]>camY-100&&b[1]<camY+ch+100) drawBuilding(b);
    // Central barricade and danger beacon.
    ctx.fillStyle='#d36b4b';ctx.globalAlpha=.65;ctx.beginPath();ctx.arc(WORLD.center.x,WORLD.center.y,13,0,Math.PI*2);ctx.fill();ctx.globalAlpha=1;
    ctx.strokeStyle='#d77a59';ctx.lineWidth=2;ctx.beginPath();ctx.arc(WORLD.center.x,WORLD.center.y,35+Math.sin(performance.now()/360)*5,0,Math.PI*2);ctx.stroke();
  }
  function renderMinimap(gs) {
    const w=mini.width,h=mini.height; mctx.clearRect(0,0,w,h);mctx.fillStyle='#263b2d';mctx.fillRect(0,0,w,h);
    const sx=w/WORLD.width, sy=h/WORLD.height;
    mctx.fillStyle='#59615a';for(const r of WORLD.roads)mctx.fillRect(r.x*sx,r.y*sy,r.w*sx,r.h*sy);
    mctx.fillStyle='#6e7b6b';for(const b of WORLD.buildings)mctx.fillRect(b[0]*sx,b[1]*sy,b[2]*sx,b[3]*sy);
    mctx.fillStyle='#a85a47';mctx.beginPath();mctx.arc(WORLD.center.x*sx,WORLD.center.y*sy,5,0,Math.PI*2);mctx.fill();
    for(const z of gs.zombies||[]){mctx.fillStyle='#d26a54';mctx.fillRect(z.x*sx-1,z.y*sy-1,2,2);}
    for(const p of gs.players||[]){if(!p.alive)continue;mctx.fillStyle=p.id===state.playerId?'#f5d17c':'#d4e0d0';mctx.beginPath();mctx.arc(p.x*sx,p.y*sy,p.id===state.playerId?3.5:2.2,0,Math.PI*2);mctx.fill();}
  }
  function renderGame(now) {
    if (!state.gameState) { ctx.fillStyle='#26372c';ctx.fillRect(0,0,cw,ch);return; }
    if (cw===0||ch===0) resizeCanvas();
    const gs=state.gameState;const me=getLocalPlayer();
    let follow=me;
    if (me && !me.alive) follow=gs.players.find(p=>p.alive) || me;
    const camX=clamp((follow?.x||WORLD.center.x)-cw/2,0,WORLD.width-cw);
    const camY=clamp((follow?.y||WORLD.center.y)-ch/2,0,WORLD.height-ch);
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,cw,ch);
    ctx.save();ctx.translate(-camX,-camY);
    drawWorldBackground(camX,camY);
    for(const item of gs.items||[]) drawLoot(item);
    for(const p of gs.players||[]){
      if(!p.inCar && p.alive) drawCar(p.carX??p.x+36,p.carY??p.y+18,p.carAngle??0,p.outfit,p.carHp);
    }
    for(const z of gs.zombies||[]) drawZombie(z,now);
    for(const p of gs.players||[]){drawPlayer(p);if(p.inCar)drawCar(p.x,p.y,p.angle,p.outfit,p.carHp);}
    ctx.restore();
    // Screen vignette and edge danger.
    const vg=ctx.createRadialGradient(cw/2,ch/2,Math.min(cw,ch)*.25,cw/2,ch/2,Math.max(cw,ch)*.7);vg.addColorStop(0,'#00000000');vg.addColorStop(1,'#08100b88');ctx.fillStyle=vg;ctx.fillRect(0,0,cw,ch);
    renderMinimap(gs);
  }

  // Browser tab background and startup.
  updateAvatarPreview(); updateCarLabels();
  connect();
  window.addEventListener('beforeunload', () => { state.manualClose = true; if (state.socket) state.socket.close(); });
  if (location.protocol === 'file:') {
    updateConnectionBadge('offline','ABRA PELO SERVIDOR');
    toast('Inicie server.js e abra o endereço http://localhost:3000.');
  }
})();
