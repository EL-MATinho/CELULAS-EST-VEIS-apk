'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { WebSocketServer, WebSocket } = require('ws');
const WORLD = require('./public/world-data.js');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const TICK_MS = 50;
const SNAPSHOT_EVERY = 2;
const MAX_PLAYERS = 8;
const MAX_ZOMBIES = 38;
const GAME_LIMIT_MS = 12 * 60 * 1000;
const PUBLIC_DIR = path.join(__dirname, 'public');

const WEAPONS = {
  pistol: { name: 'Pistola', damage: 27, rate: 390, range: 420, ammo: 12, reserve: 60, reload: 1050, spread: 0.045 },
  smg: { name: 'Submetralhadora', damage: 11, rate: 105, range: 340, ammo: 30, reserve: 120, reload: 1350, spread: 0.13 },
  shotgun: { name: 'Escopeta', damage: 38, rate: 760, range: 225, ammo: 6, reserve: 36, reload: 1550, spread: 0.22 },
  rifle: { name: 'Rifle', damage: 25, rate: 590, range: 610, ammo: 8, reserve: 56, reload: 1450, spread: 0.025 }
};
const ZOMBIE_TYPES = {
  common: { hp: 48, speed: 52, damage: 8, score: 2, radius: 13 },
  runner: { hp: 29, speed: 94, damage: 6, score: 3, radius: 11 },
  brute: { hp: 145, speed: 34, damage: 18, score: 5, radius: 19 }
};
const ENGINE_PRESETS = {
  turbo: { acceleration: 6, topSpeed: 2, handling: 5, durability: 3 },
  speed: { acceleration: 3, topSpeed: 6, handling: 4, durability: 3 },
  reinforced: { acceleration: 3, topSpeed: 3, handling: 4, durability: 6 },
  balanced: { acceleration: 4, topSpeed: 4, handling: 4, durability: 4 }
};
const rooms = new Map();
const clients = new Map();

const mime = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon'
};

function httpHandler(req, res) {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (url.pathname === '/health') {
    res.writeHead(200, { 'content-type': 'application/json' });
    return res.end(JSON.stringify({ ok: true, rooms: rooms.size, players: clients.size, version: '0.1.0' }));
  }
  let target = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname);
  target = path.normalize(target).replace(/^([.][.][/\\])+/, '');
  const file = path.join(PUBLIC_DIR, target);
  if (!file.startsWith(PUBLIC_DIR)) {
    res.writeHead(403); return res.end('Forbidden');
  }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('Arquivo não encontrado.'); }
    res.writeHead(200, { 'content-type': mime[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-cache' });
    res.end(data);
  });
}

const server = http.createServer(httpHandler);
const wss = new WebSocketServer({ server, path: '/ws', maxPayload: 16 * 1024 });

function send(ws, type, data = {}) {
  if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ type, ...data }));
}
function broadcast(room, type, data = {}) {
  for (const p of room.players.values()) if (p.ws && p.connected) send(p.ws, type, data);
}
function safeText(value, max = 18, fallback = 'Sobrevivente') {
  return String(value || fallback).replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, max) || fallback;
}
function clamp(value, min, max) { return Math.max(min, Math.min(max, Number(value) || 0)); }
function distance(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }
function randomCode() { return crypto.randomBytes(3).toString('hex').toUpperCase(); }
function randomId() { return crypto.randomBytes(8).toString('hex'); }
function validColor(v, fallback) { return /^#[0-9a-fA-F]{6}$/.test(String(v || '')) ? v : fallback; }

function normalizeCar(input = {}) {
  const keys = ['acceleration', 'topSpeed', 'handling', 'durability'];
  const result = {};
  for (const key of keys) result[key] = Math.round(clamp(input[key] ?? 4, 1, 7));
  // Keep a fixed build budget of 16 points. Scale excess proportionally, then distribute leftovers.
  let sum = keys.reduce((n, k) => n + result[k], 0);
  while (sum > 16) {
    const k = keys.slice().reverse().find(key => result[key] > 1);
    if (!k) break; result[k]--; sum--;
  }
  while (sum < 16) {
    const k = keys.find(key => result[key] < 7);
    if (!k) break; result[k]++; sum++;
  }
  return result;
}

function makePlayer(ws, profile, room, index) {
  const angle = (Math.PI * 2 * index) / Math.max(2, 8) - Math.PI / 2;
  const radius = 760;
  const spawn = { x: WORLD.center.x + Math.cos(angle) * radius, y: WORLD.center.y + Math.sin(angle) * radius };
  const weapon = Object.hasOwn(WEAPONS, profile.weapon) ? profile.weapon : 'pistol';
  const spec = WEAPONS[weapon];
  const car = normalizeCar(profile.car);
  const id = randomId();
  return {
    id, token: safeText(profile.token, 80, randomId()), ws, connected: true,
    name: safeText(profile.name), color: validColor(profile.color, '#e7a34a'),
    hair: validColor(profile.hair, '#2c2523'), outfit: validColor(profile.outfit, '#526b62'),
    weapon, x: spawn.x, y: spawn.y, angle: 0, hp: 100, alive: true,
    score: 0, zombieKills: 0, playerKills: 0, survivalMs: 0,
    ammo: spec.ammo, reserve: spec.reserve, reloadingUntil: 0, lastShot: 0, lastDamage: 0,
    inCar: false, carConfig: car,
    vehicle: { x: spawn.x + 36, y: spawn.y + 18, angle: 0, hp: 180 + car.durability * 20, maxHp: 180 + car.durability * 20, fuel: 100, speed: 0, lastBump: 0, lastNoise: 0 },
    disconnectedAt: 0,
    input: { mx: 0, my: 0, ax: 1, ay: 0, shoot: false, reload: false, interact: false, accelerate: 0, steer: 0, brake: false },
    previousInteract: false, respawnAt: 0
  };
}

function makeRoom(hostWs, profile) {
  let code = randomCode(); while (rooms.has(code)) code = randomCode();
  const room = {
    code, hostId: null, players: new Map(), zombies: new Map(), phase: 'lobby',
    createdAt: Date.now(), startedAt: 0, lastSpawnAt: 0, lastScoreAt: 0,
    tickCount: 0, gameEndAt: 0, items: WORLD.lootSpots.map((v, i) => ({ id: `loot-${i}`, x: v[0], y: v[1], kind: v[2], active: true })),
    effects: [], initialPlayers: 0, noises: []
  };
  const p = makePlayer(hostWs, profile, room, 0);
  room.hostId = p.id;
  room.players.set(p.id, p);
  rooms.set(code, room);
  clients.set(hostWs, { roomCode: code, playerId: p.id });
  return { room, player: p };
}

function getRoomState(room) {
  const players = [...room.players.values()].map(p => ({
    id: p.id, name: p.name, color: p.color, hair: p.hair, outfit: p.outfit,
    x: p.inCar ? p.vehicle.x : p.x, y: p.inCar ? p.vehicle.y : p.y,
    angle: p.inCar ? p.vehicle.angle : p.angle, hp: p.hp, alive: p.alive,
    score: p.score, zombieKills: p.zombieKills, playerKills: p.playerKills,
    weapon: p.weapon, ammo: p.ammo, reserve: p.reserve, inCar: p.inCar,
    carHp: p.vehicle.hp, carMaxHp: p.vehicle.maxHp, fuel: p.vehicle.fuel,
    carX: p.vehicle.x, carY: p.vehicle.y, carAngle: p.vehicle.angle,
    carConfig: p.carConfig, connected: p.connected, host: p.id === room.hostId
  }));
  return {
    code: room.code, phase: room.phase, hostId: room.hostId,
    startedAt: room.startedAt, serverTime: Date.now(), players,
    zombies: [...room.zombies.values()].map(z => ({ id: z.id, type: z.type, x: z.x, y: z.y, angle: z.angle, hp: z.hp, maxHp: z.maxHp })),
    items: room.items.filter(i => i.active), gameEndAt: room.gameEndAt,
    remainingMs: room.phase === 'running' ? Math.max(0, GAME_LIMIT_MS - (Date.now() - room.startedAt)) : GAME_LIMIT_MS
  };
}
function sendState(room) { broadcast(room, 'state', { state: getRoomState(room) }); }
function findPlayerByToken(room, token) { return [...room.players.values()].find(p => p.token === token); }

function addZombie(room, type, x, y) {
  const spec = ZOMBIE_TYPES[type];
  const id = randomId();
  room.zombies.set(id, { id, type, x, y, angle: 0, hp: spec.hp, maxHp: spec.hp, lastAttack: 0, targetId: null, wobble: Math.random() * 10 });
}
function spawnHorde(room, amount = 1) {
  for (let i = 0; i < amount && room.zombies.size < MAX_ZOMBIES; i++) {
    const angle = Math.random() * Math.PI * 2;
    const radius = 95 + Math.random() * 240;
    const x = WORLD.center.x + Math.cos(angle) * radius;
    const y = WORLD.center.y + Math.sin(angle) * radius;
    const roll = Math.random();
    const type = roll < 0.68 ? 'common' : roll < 0.91 ? 'runner' : 'brute';
    addZombie(room, type, x, y);
  }
}
function startGame(room) {
  room.phase = 'running'; room.startedAt = Date.now(); room.lastScoreAt = room.startedAt; room.lastSpawnAt = room.startedAt;
  room.initialPlayers = [...room.players.values()].filter(p => p.connected).length;
  room.zombies.clear(); spawnHorde(room, 12);
  for (const p of room.players.values()) {
    p.hp = 100; p.alive = p.connected; p.score = 0; p.zombieKills = 0; p.playerKills = 0; p.survivalMs = 0;
    const spec = WEAPONS[p.weapon]; p.ammo = spec.ammo; p.reserve = spec.reserve; p.reloadingUntil = 0;
    p.vehicle.hp = p.vehicle.maxHp; p.vehicle.fuel = 100; p.vehicle.speed = 0; p.inCar = false;
  }
  broadcast(room, 'notice', { text: 'A invasão começou. Sobreviva!' });
}

function collidesBuilding(x, y, radius = 16) {
  for (const b of WORLD.buildings) {
    if (x + radius > b[0] && x - radius < b[0] + b[2] && y + radius > b[1] && y - radius < b[1] + b[3]) return true;
  }
  return false;
}
function moveWithCollision(entity, dx, dy, radius = 15) {
  const nx = clamp(entity.x + dx, radius, WORLD.width - radius);
  const ny = clamp(entity.y + dy, radius, WORLD.height - radius);
  if (!collidesBuilding(nx, entity.y, radius)) entity.x = nx;
  if (!collidesBuilding(entity.x, ny, radius)) entity.y = ny;
}
function damagePlayer(room, p, amount, attackerId = null) {
  if (!p.alive) return;
  p.hp = Math.max(0, p.hp - amount); p.lastDamage = Date.now();
  if (p.hp <= 0) {
    p.alive = false; p.inCar = false; p.vehicle.speed = 0;
    const attacker = attackerId && room.players.get(attackerId);
    if (attacker && attacker.id !== p.id) { attacker.playerKills++; attacker.score += 8; }
    broadcast(room, 'notice', { text: `${p.name} foi eliminado.` });
  }
}
function damageZombie(room, z, amount, attacker) {
  z.hp -= amount;
  if (z.hp <= 0) {
    room.zombies.delete(z.id);
    if (attacker) { attacker.zombieKills++; attacker.score += ZOMBIE_TYPES[z.type].score; }
  }
}
function shoot(room, p, now) {
  const spec = WEAPONS[p.weapon];
  if (p.reloadingUntil > now || p.ammo <= 0 || now - p.lastShot < spec.rate) return;
  p.lastShot = now; p.ammo--;
  const aimMag = Math.hypot(p.input.ax, p.input.ay);
  const ax = aimMag > 0.1 ? p.input.ax / aimMag : Math.cos(p.angle);
  const ay = aimMag > 0.1 ? p.input.ay / aimMag : Math.sin(p.angle);
  const aimAngle = Math.atan2(ay, ax) + (Math.random() - 0.5) * spec.spread;
  const dx = Math.cos(aimAngle), dy = Math.sin(aimAngle);
  let target = null, targetDist = spec.range + 1, targetKind = null;
  const consider = (obj, kind, radius) => {
    const vx = obj.x - (p.inCar ? p.vehicle.x : p.x), vy = obj.y - (p.inCar ? p.vehicle.y : p.y);
    const d = Math.hypot(vx, vy);
    if (d > spec.range || d > targetDist) return;
    const dot = (vx * dx + vy * dy) / (d || 1);
    if (dot < (p.weapon === 'shotgun' ? 0.91 : 0.965)) return;
    // Rough line-of-sight obstruction by buildings.
    const steps = Math.max(2, Math.ceil(d / 28));
    for (let i = 1; i < steps; i++) {
      const t = i / steps;
      if (collidesBuilding((p.inCar ? p.vehicle.x : p.x) + vx * t, (p.inCar ? p.vehicle.y : p.y) + vy * t, 3)) return;
    }
    target = obj; targetDist = d; targetKind = kind;
  };
  for (const z of room.zombies.values()) consider(z, 'zombie', ZOMBIE_TYPES[z.type].radius);
  for (const other of room.players.values()) if (other.id !== p.id && other.alive) consider({ x: other.inCar ? other.vehicle.x : other.x, y: other.inCar ? other.vehicle.y : other.y, player: other }, 'player', 15);
  if (target) {
    if (targetKind === 'zombie') {
      const damage = p.weapon === 'shotgun' ? spec.damage * (targetDist < 115 ? 1.35 : 0.85) : spec.damage;
      damageZombie(room, target, damage, p);
    } else damagePlayer(room, target.player, spec.damage, p.id);
  }
  const shotX = p.inCar ? p.vehicle.x : p.x, shotY = p.inCar ? p.vehicle.y : p.y;
  room.noises.push({ x: shotX, y: shotY, radius: p.weapon === 'smg' ? 460 : p.weapon === 'shotgun' ? 560 : 500, expires: now + 3600 });
  room.effects.push({ kind: 'shot', x: shotX, y: shotY, angle: aimAngle, until: now + 110 });
}
function beginReload(p, now) {
  const spec = WEAPONS[p.weapon];
  if (p.reloadingUntil > now || p.ammo >= spec.ammo || p.reserve <= 0) return;
  p.reloadingUntil = now + spec.reload;
}
function finishReload(p, now) {
  if (p.reloadingUntil && p.reloadingUntil <= now) {
    const spec = WEAPONS[p.weapon]; const amount = Math.min(spec.ammo - p.ammo, p.reserve);
    p.ammo += amount; p.reserve -= amount; p.reloadingUntil = 0;
  }
}
function updatePlayer(room, p, dt, now) {
  if (!p.alive || !p.connected) return;
  const input = p.input;
  if (input.reload) beginReload(p, now);
  finishReload(p, now);
  if (input.interact && !p.previousInteract) {
    if (p.inCar) { p.inCar = false; p.x = p.vehicle.x + Math.cos(p.vehicle.angle + Math.PI / 2) * 30; p.y = p.vehicle.y + Math.sin(p.vehicle.angle + Math.PI / 2) * 30; }
    else if (distance(p, p.vehicle) < 70 && p.vehicle.hp > 0) p.inCar = true;
    else {
      const item = room.items.find(i => i.active && distance(p, i) < 48);
      if (item) {
        item.active = false;
        if (item.kind === 'medkit') p.hp = Math.min(100, p.hp + 38);
        if (item.kind === 'ammo') { p.reserve = Math.min(180, p.reserve + 30); }
        if (item.kind === 'fuel') p.vehicle.fuel = Math.min(100, p.vehicle.fuel + 42);
        if (item.kind === 'repair') p.vehicle.hp = Math.min(p.vehicle.maxHp, p.vehicle.hp + 65);
        send(p.ws, 'notice', { text: `Coletado: ${item.kind === 'medkit' ? 'kit médico' : item.kind === 'ammo' ? 'munição' : item.kind === 'fuel' ? 'combustível' : 'reparo'}.` });
      }
    }
  }
  p.previousInteract = input.interact;
  if (p.inCar && p.vehicle.hp > 0 && p.vehicle.fuel > 0) {
    const c = p.carConfig; const v = p.vehicle;
    const accel = (0.04 + c.acceleration * 0.012) * 60 * dt;
    const maxSpeed = 1.0 + c.topSpeed * 0.48;
    if (input.accelerate > 0) v.speed = Math.min(maxSpeed, v.speed + accel * input.accelerate);
    else if (input.accelerate < 0 || input.brake) v.speed = Math.max(-maxSpeed * 0.45, v.speed - accel * 1.8);
    else v.speed *= Math.pow(0.985, dt * 60);
    const turnFactor = (0.012 + c.handling * 0.004) * Math.min(1.35, Math.abs(v.speed) / 1.6 + 0.35);
    v.angle += input.steer * turnFactor * (v.speed >= 0 ? 1 : -1) * dt * 60;
    const oldX = v.x, oldY = v.y;
    moveWithCollision(v, Math.cos(v.angle) * v.speed * 60 * dt, Math.sin(v.angle) * v.speed * 60 * dt, 22);
    if (oldX === v.x && oldY === v.y && Math.abs(v.speed) > 0.3) { v.hp = Math.max(0, v.hp - 2); v.speed *= -0.22; }
    v.fuel = Math.max(0, v.fuel - Math.abs(v.speed) * dt * 0.045);
    if (Math.abs(v.speed) > 1.45 && now - v.lastNoise > 1100) {
      room.noises.push({ x: v.x, y: v.y, radius: 390, expires: now + 2300 }); v.lastNoise = now;
    }
    if (v.hp <= 0) { p.inCar = false; p.x = v.x; p.y = v.y; v.speed = 0; }
  } else if (!p.inCar) {
    const mag = Math.hypot(input.mx, input.my) || 1;
    const speed = 190;
    const dx = input.mx / mag * speed * dt, dy = input.my / mag * speed * dt;
    if (Math.abs(input.mx) + Math.abs(input.my) > 0.05) p.angle = Math.atan2(input.my, input.mx);
    moveWithCollision(p, dx, dy, 14);
  }
  if (input.shoot) shoot(room, p, now);
}
function updateZombies(room, dt, now) {
  const living = [...room.players.values()].filter(p => p.alive && p.connected);
  room.noises = room.noises.filter(n => n.expires > now);
  for (const z of room.zombies.values()) {
    const spec = ZOMBIE_TYPES[z.type];
    let targetPlayer = null, bestPlayer = Infinity;
    for (const p of living) {
      const obj = p.inCar ? p.vehicle : p;
      const d = distance(z, obj);
      if (d < bestPlayer) { bestPlayer = d; targetPlayer = p; }
    }
    // Gunshots and loud engines attract nearby zombies for a short time.
    let targetPoint = targetPlayer ? (targetPlayer.inCar ? targetPlayer.vehicle : targetPlayer) : null;
    let bestNoise = Infinity;
    for (const noise of room.noises) {
      const d = distance(z, noise);
      if (d < noise.radius && d < bestNoise && (!targetPoint || d < bestPlayer * 1.35)) {
        bestNoise = d; targetPoint = noise;
      }
    }
    if (!targetPoint) continue;
    const dx = targetPoint.x - z.x, dy = targetPoint.y - z.y, d = Math.hypot(dx, dy) || 1;
    z.angle = Math.atan2(dy, dx);
    const isPlayerTarget = targetPoint === (targetPlayer ? (targetPlayer.inCar ? targetPlayer.vehicle : targetPlayer) : null);
    const speed = spec.speed * (d < 280 ? 1 : 0.78);
    if (!isPlayerTarget || d > (targetPlayer?.inCar ? 32 : 23)) {
      const beforeX = z.x, beforeY = z.y;
      moveWithCollision(z, dx / d * speed * dt, dy / d * speed * dt, spec.radius);
      // If blocked by a building, slightly slide around it.
      if (z.x === beforeX && z.y === beforeY) moveWithCollision(z, -dy / d * speed * dt, dx / d * speed * dt, spec.radius);
    } else if (now - z.lastAttack > 1000) {
      z.lastAttack = now;
      if (targetPlayer.inCar && targetPlayer.vehicle.hp > 0) targetPlayer.vehicle.hp = Math.max(0, targetPlayer.vehicle.hp - spec.damage * 1.35);
      else damagePlayer(room, targetPlayer, spec.damage);
    }
  }
}
function updateVehicleHits(room, now) {
  for (const p of room.players.values()) {
    if (!p.alive || !p.inCar || Math.abs(p.vehicle.speed) < 1.0) continue;
    for (const z of [...room.zombies.values()]) {
      if (distance(p.vehicle, z) < 29 && now - (z.lastVehicleHit || 0) > 550) {
        z.lastVehicleHit = now;
        damageZombie(room, z, Math.abs(p.vehicle.speed) * 19, p);
        p.vehicle.speed *= 0.91;
      }
    }
    for (const other of room.players.values()) {
      if (other.id !== p.id && other.alive && !other.inCar && distance(p.vehicle, other) < 28 && now - p.vehicle.lastBump > 650) {
        p.vehicle.lastBump = now; damagePlayer(room, other, Math.abs(p.vehicle.speed) * 5, p.id);
      }
    }
  }
}
function finishGame(room, reason = 'time') {
  if (room.phase !== 'running') return;
  room.phase = 'ended'; room.gameEndAt = Date.now();
  const ranked = [...room.players.values()].sort((a, b) => (b.alive - a.alive) || b.score - a.score || b.survivalMs - a.survivalMs);
  const winner = ranked[0];
  if (winner && winner.alive) winner.score += 25;
  broadcast(room, 'gameOver', { reason, ranking: ranked.map((p, index) => ({ position: index + 1, name: p.name, score: p.score, zombieKills: p.zombieKills, playerKills: p.playerKills, survivalSeconds: Math.floor(p.survivalMs / 1000), alive: p.alive })), winner: winner ? winner.name : null });
}
function stepRoom(room, dt, now) {
  if (room.phase !== 'running') return;
  for (const p of room.players.values()) {
    if (!p.connected && p.disconnectedAt && now - p.disconnectedAt > 45000) p.alive = false;
    if (p.alive) p.survivalMs += dt * 1000;
    updatePlayer(room, p, dt, now);
  }
  updateZombies(room, dt, now);
  updateVehicleHits(room, now);
  const elapsed = now - room.startedAt;
  if (elapsed - room.lastScoreAt >= 60000) {
    for (const p of room.players.values()) if (p.alive) p.score += 2;
    room.lastScoreAt = now;
  }
  const spawnInterval = Math.max(780, 2300 - Math.floor(elapsed / 60000) * 180);
  if (now - room.lastSpawnAt >= spawnInterval && room.zombies.size < MAX_ZOMBIES) {
    spawnHorde(room, elapsed > 180000 ? 2 : 1); room.lastSpawnAt = now;
  }
  room.effects = room.effects.filter(e => e.until > now);
  const aliveCount = [...room.players.values()].filter(p => p.alive).length;
  if (aliveCount <= 1 && room.initialPlayers >= 2) finishGame(room, 'last-survivor');
  else if (elapsed >= GAME_LIMIT_MS) finishGame(room, 'time');
}

wss.on('connection', ws => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws, 'error', { message: 'Mensagem inválida.' }); }
    if (!msg || typeof msg.type !== 'string') return;

    if (msg.type === 'createRoom') {
      if (clients.has(ws)) return send(ws, 'error', { message: 'Você já está em uma sala.' });
      const { room, player } = makeRoom(ws, msg.profile || {});
      send(ws, 'joined', { roomCode: room.code, playerId: player.id, token: player.token, isHost: true, state: getRoomState(room) });
      sendState(room); return;
    }
    if (msg.type === 'joinRoom') {
      if (clients.has(ws)) return send(ws, 'error', { message: 'Você já está em uma sala.' });
      const code = safeText(msg.roomCode, 6, '').toUpperCase(); const room = rooms.get(code);
      if (!room) return send(ws, 'error', { message: 'Sala não encontrada.' });
      if (room.phase !== 'lobby') return send(ws, 'error', { message: 'A partida já começou.' });
      if (room.players.size >= MAX_PLAYERS) return send(ws, 'error', { message: 'Sala cheia (máximo de 8 jogadores).' });
      const p = makePlayer(ws, msg.profile || {}, room, room.players.size);
      room.players.set(p.id, p); clients.set(ws, { roomCode: code, playerId: p.id });
      send(ws, 'joined', { roomCode: code, playerId: p.id, token: p.token, isHost: false, state: getRoomState(room) });
      broadcast(room, 'notice', { text: `${p.name} entrou na zona.` }); sendState(room); return;
    }
    if (msg.type === 'reconnect') {
      const code = safeText(msg.roomCode, 6, '').toUpperCase(); const room = rooms.get(code);
      if (!room) return send(ws, 'error', { message: 'A sala não está mais disponível para reconexão.' });
      const p = findPlayerByToken(room, safeText(msg.token, 80, ''));
      if (!p) return send(ws, 'error', { message: 'Sessão não encontrada.' });
      if (p.ws && p.ws !== ws) clients.delete(p.ws);
      p.ws = ws; p.connected = true; p.disconnectedAt = 0; clients.set(ws, { roomCode: code, playerId: p.id });
      send(ws, 'joined', { roomCode: code, playerId: p.id, token: p.token, isHost: p.id === room.hostId, state: getRoomState(room) });
      broadcast(room, 'notice', { text: `${p.name} reconectou.` }); sendState(room); return;
    }

    const info = clients.get(ws);
    if (!info) return send(ws, 'error', { message: 'Entre em uma sala primeiro.' });
    const room = rooms.get(info.roomCode); const p = room && room.players.get(info.playerId);
    if (!room || !p) return;

    if (msg.type === 'startGame') {
      if (p.id !== room.hostId) return send(ws, 'error', { message: 'Somente o anfitrião pode iniciar.' });
      const connected = [...room.players.values()].filter(player => player.connected);
      if (connected.length < 2) return send(ws, 'error', { message: 'São necessários pelo menos 2 jogadores.' });
      if (room.phase !== 'lobby') return;
      startGame(room); sendState(room); return;
    }
    if (msg.type === 'input') {
      if (!p.alive || room.phase !== 'running') return;
      const i = msg.input || {};
      p.input = {
        mx: clamp(i.mx, -1, 1), my: clamp(i.my, -1, 1),
        ax: clamp(i.ax, -1, 1), ay: clamp(i.ay, -1, 1),
        shoot: !!i.shoot, reload: !!i.reload, interact: !!i.interact,
        accelerate: clamp(i.accelerate, -1, 1), steer: clamp(i.steer, -1, 1), brake: !!i.brake
      };
      return;
    }
    if (msg.type === 'keepalive') { send(ws, 'pong'); return; }
    if (msg.type === 'leaveRoom') {
      p.connected = false; p.disconnectedAt = Date.now(); clients.delete(ws); p.ws = null; send(ws, 'left'); sendState(room); return;
    }
  });
  ws.on('close', () => {
    const info = clients.get(ws); if (!info) return;
    clients.delete(ws);
    const room = rooms.get(info.roomCode); const p = room && room.players.get(info.playerId);
    if (p && p.ws === ws) { p.connected = false; p.disconnectedAt = Date.now(); p.ws = null; broadcast(room, 'notice', { text: `${p.name} perdeu a conexão. Tentando reconectar...` }); sendState(room); }
  });
  ws.on('error', () => {});
});

setInterval(() => {
  const now = Date.now();
  for (const room of rooms.values()) {
    room.tickCount++;
    stepRoom(room, TICK_MS / 1000, now);
    if (room.tickCount % SNAPSHOT_EVERY === 0) sendState(room);
    // Keep abandoned rooms in memory briefly to support reconnection.
    if ([...room.players.values()].every(p => !p.connected) && now - room.createdAt > 5 * 60 * 1000) rooms.delete(room.code);
  }
}, TICK_MS);

const heartbeat = setInterval(() => {
  for (const ws of wss.clients) {
    if (ws.isAlive === false) { ws.terminate(); continue; }
    ws.isAlive = false; ws.ping();
  }
}, 25000);
wss.on('close', () => clearInterval(heartbeat));

server.listen(PORT, HOST, () => {
  const ips = Object.values(os.networkInterfaces()).flat().filter(v => v && v.family === 'IPv4' && !v.internal).map(v => v.address);
  console.log(`Zona de Impacto disponível em http://localhost:${PORT}`);
  if (ips.length) console.log(`Rede local: ${ips.map(ip => `http://${ip}:${PORT}`).join(' | ')}`);
  console.log(`WebSocket: ws://localhost:${PORT}/ws`);
});
